# Expanding flex cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/z-/pen/OBPJKK](https://codepen.io/z-/pen/OBPJKK).

![](https://i.imgur.com/W6mroTN.gif)

Edit 9th October 2021: Added theme switcher